
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Service - Timetable</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url("/static/images/login1.jpg");
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        header {
            background-color: rgba(144, 238, 144);
            color: white;
            text-align: center;
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        nav {
            display: flex;
            justify-content: right;
            background-color: #333;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            padding: 10px 5px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        nav a:hover {
            background-color: #555;
        }

        main {
            padding: 20px;
            width: 100%;
            box-sizing: border-box;
        }

        section {
            margin-bottom: 40px;
        }

        h1, h2 {
            color: #333;
        }

        p {
            line-height: 1.6;
            margin-bottom: 15px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.8); /* Transparent white background */
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }

        th {
            background-color: #4caf50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* New div for hover effect */
        .hover-details {
            display: none;
            position: absolute;
            background-color: white;
            border: 1px solid #ddd;
            padding: 10px;
            z-index: 1;
        }

        tr:hover .hover-details {
            display: block;
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
            position: fixed;
            bottom: 0;
            min-height: 10vh;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bus scheduler services</h1>
    </header>

    <nav>
        <a href="homepage.html">Home</a>
        <a href="safetyrules.html">Safety Rules</a>
        <a href="">Time Table</a>
        <a href="contactus.html">Contact Us</a>
        <a href="find.html">Find Bus</a>
    </nav>
    <?php
    include("data_connect.php");
// Fetch data from the time_table
    $sql = "SELECT * FROM time_table";
    $result = $conn->query($sql);

    // Generate the HTML table dynamically
    if ($result->num_rows > 0) {
        echo "<table id='busTable'>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Serial Number</th>";
        echo "<th>Source City</th>";
        echo "<th>Destination City</th>";
        echo "<th>Bus Operator</th>";
        echo "<th>Source Timing</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['source'] . "</td>";
            echo "<td>" . $row['destination'] . "</td>";
            echo "<td>" . $row['busNo'] . "</td>";
            echo "<td>" . $row['toa'] . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "0 results";
    }

    $conn->close();

?>

</br></br></br></br>
</br></br></br></br>
<footer>
        <p>&copy; 2024 Bus Service. All Rights Reserved</p>
    </footer>
</body>
</html>

