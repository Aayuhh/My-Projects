<?php
// Assuming you have already established a database connection
// Replace the database credentials with your own
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bus_data";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
