<?php
// Assuming you have already established a database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bus_data";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve source and destination cities from the form submission
$source = $_POST['source'];
$destination = $_POST['destination'];

// Fetch data from the databus table based on the selected cities
$sql = "SELECT * FROM time_table WHERE source = '$source' AND destination = '$destination'";
$result = $conn->query($sql);

// Prepare the data as an array
$data = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}

// Close the database connection
$conn->close();

// Return the data as JSON
echo json_encode($data);
?>
