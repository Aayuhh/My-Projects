def my_reverse(string):
    result = string[::-1]
    return result

string_list = ["apple", "banana", "cherry", "pineapple"]
result_list = [my_reverse(s) for s in string_list]
print(result_list)
