my_string = "I am a CSE student."
print(my_string)
