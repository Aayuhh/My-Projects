text="HELLO WORLD"
result=text.lower()
print (result)