def find_largest(numbers):
    if not numbers:
        return None
    
    largest = numbers[0]
    
    for num in numbers:
        if num > largest:
            largest = num
    
    return largest

number_list = [50, 40, 89, 77, 100, 28, 55]
result = find_largest(number_list)
print(f"The largest number is: {result}")
