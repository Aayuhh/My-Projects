a=float(input("enter first value"))
b=float(input("enter second value"))
result=a+b
print("the sum of both values is",result)