a=input("enter your name")
print("hello "+a+" how are you")