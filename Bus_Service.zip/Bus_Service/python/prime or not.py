num = int(input("Enter the number between 2 to 100: "))

if (num <= 1):
    print("Number should be greater than 1")
else:
    flag = True 
    for i in range(2, num):
        if num % i == 0:
            flag = False
            break

    if flag:
        print("Prime number")
    else:
        print("Not a prime number")
