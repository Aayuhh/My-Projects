a=2000
b=2501
for i in range(a,b):
    if(i%17==0)and (i%5!=0):
        print(i)