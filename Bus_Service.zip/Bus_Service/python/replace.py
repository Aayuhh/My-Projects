text="hello world"
result=text.replace("hello","hey")
print(result)