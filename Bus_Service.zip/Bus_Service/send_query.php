<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

        $name=$_POST['name'];
    $email = $_POST["email"];
$message= $_POST["message"];


 

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';  // Gmail SMTP server
        $mail->SMTPAuth = true;
        $mail->Username = 'vikuu2204@gmail.com';  // Your Gmail email address
        $mail->Password = 'xnba wlge wxbt atnv';  // Your Gmail password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;  // Use STARTTLS
        $mail->Port = 587;  // SMTP port (587 for TLS)

        // Sender and recipient details
        $mail->setFrom('vikuu2204@gmail.com', 'ADMIN');  // Your Gmail email address
        $mail->addAddress('vikuu2204@gmail.com');  // User's email address

        // Email content
        $mail->isHTML(true);
        $mail->Subject = "Query From '$email'";
        $mail->Body = "$message";

        // Send the email
        $mail->send();

        // Redirect to OTP verification page
        header("Location:contactus1.html?email=$email&otp=$otp&password=$password&name=$name");
    } catch (Exception $e) {
        echo 'Email delivery failed. Error: ' . $mail->ErrorInfo;
    }

?>
