import tkinter as tk
from tkinter import messagebox, scrolledtext
import rsa
import random
import string
from cryptography.fernet import Fernet
import base64

# ------------ Word Mapping and Key Generation ------------

WORD_LIST = [
    "apple", "banana", "carrot", "delta", "echo", "foxtrot", "grape", "hotel", "india",
    "jungle", "kiwi", "lemon", "mango", "nectar", "orange", "peach", "quartz", "raspberry",
    "strawberry", "tomato", "umbrella", "vanilla", "watermelon", "xray", "yam", "zebra",
    "apricot", "blueberry", "coconut", "dragonfruit", "elderberry", "fig", "guava", "honeydew",
    "iceberg", "jackfruit", "kumquat", "lime", "mulberry", "nutmeg", "olive", "papaya",
    "quince", "radish", "spinach", "tangerine", "ugli", "violet", "walnut", "xylophone",
    "yucca", "zucchini", "aloe", "beet", "cashew", "dill", "endive", "fennel", "garlic",
    "hazelnut", "ink", "jalapeno", "kale", "licorice", "mint", "noodle", "oregano", "pistachio"
]


class KeyManager:
    def __init__(self):
        # Changed to 1024-bit RSA key for shorter encrypted key
        self.public_key, self.private_key = rsa.newkeys(1024)


class MessageEncoder:
    def __init__(self):
        self.char_to_word = {}
        self.word_to_char = {}
        self._generate_mappings()

    def _generate_mappings(self):
        available_words = WORD_LIST.copy()
        random.shuffle(available_words)
        characters = string.ascii_letters + string.digits + " "

        for char, word in zip(characters, available_words[:len(characters)]):
            self.char_to_word[char] = word
            self.word_to_char[word] = char

    def encode(self, message):
        return ' '.join(self.char_to_word[c] for c in message if c in self.char_to_word)

    def decode(self, encoded_message):
        return ''.join(self.word_to_char.get(w, '?') for w in encoded_message.split())


class HybridEncryptor:
    def __init__(self, public_key, private_key):
        self.public_key = public_key
        self.private_key = private_key

    def encrypt(self, message):
        aes_key = Fernet.generate_key()
        f = Fernet(aes_key)
        encrypted_message = f.encrypt(message.encode())
        encrypted_key = rsa.encrypt(aes_key, self.public_key)

        encoded_key = base64.urlsafe_b64encode(encrypted_key).decode()
        encoded_message = base64.urlsafe_b64encode(encrypted_message).decode()

        return encoded_key, encoded_message

    def decrypt(self, encoded_key_b64, encoded_msg_b64):
        encrypted_key = base64.urlsafe_b64decode(encoded_key_b64)
        encrypted_msg = base64.urlsafe_b64decode(encoded_msg_b64)

        aes_key = rsa.decrypt(encrypted_key, self.private_key)
        f = Fernet(aes_key)
        return f.decrypt(encrypted_msg).decode()


# ------------ GUI Application ------------

class EncoderApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🔐 Message Encoder & Decoder")
        self.root.geometry("880x740")
        self.root.configure(bg="#202040")

        self.keys = KeyManager()
        self.encoder = MessageEncoder()
        self.encryptor = HybridEncryptor(self.keys.public_key, self.keys.private_key)

        self.build_gui()

    def build_gui(self):
        # Title
        tk.Label(self.root, text="🔐 Secure Message Encoder & Decoder",
                 font=("Helvetica", 20, "bold"), fg="white", bg="#202040").pack(pady=15)

        # Message Entry
        tk.Label(self.root, text="Plain Message:", font=("Helvetica", 11),
                 fg="lightgray", bg="#202040").pack()
        self.input_entry = tk.Entry(self.root, font=("Helvetica", 12), width=80, bg="#f2f2f2")
        self.input_entry.pack(pady=5)

        # Buttons
        btn_frame = tk.Frame(self.root, bg="#202040")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="🔐 Encode & Encrypt", command=self.encode_encrypt,
                  bg="#28a745", fg="white", font=("Helvetica", 10, "bold"),
                  width=18, pady=6).grid(row=0, column=0, padx=8)

        tk.Button(btn_frame, text="🔓 Decrypt & Decode", command=self.decrypt_decode,
                  bg="#007bff", fg="white", font=("Helvetica", 10, "bold"),
                  width=18, pady=6).grid(row=0, column=1, padx=8)

        # Encrypted Key Field
        tk.Label(self.root, text="Encrypted AES Key:", font=("Helvetica", 11),
                 fg="lightgray", bg="#202040").pack(pady=(15, 0))
        self.encrypted_key_text = tk.Text(self.root, height=3, width=100,
                                          font=("Courier New", 10), bg="#f4f4f4")
        self.encrypted_key_text.pack(pady=4)

        # Encrypted Message Field
        tk.Label(self.root, text="Encrypted Message:", font=("Helvetica", 11),
                 fg="lightgray", bg="#202040").pack(pady=(10, 0))
        self.encrypted_msg_text = tk.Text(self.root, height=6, width=100,
                                          font=("Courier New", 10), bg="#f4f4f4")
        self.encrypted_msg_text.pack(pady=4)

        # Output Area
        tk.Label(self.root, text="Output:", font=("Helvetica", 11),
                 fg="lightgray", bg="#202040").pack(pady=5)
        self.output_area = scrolledtext.ScrolledText(self.root, width=100, height=14,
                                                     font=("Courier New", 10), bg="#ffffff", fg="#111")
        self.output_area.pack(pady=8)

    def encode_encrypt(self):
        msg = self.input_entry.get()
        if not msg.strip():
            messagebox.showwarning("Missing Message", "Please enter a message to encode.")
            return

        try:
            encoded = self.encoder.encode(msg)
            enc_key_b64, enc_msg_b64 = self.encryptor.encrypt(encoded)

            # Place into encrypted fields
            self.encrypted_key_text.delete("1.0", tk.END)
            self.encrypted_key_text.insert(tk.END, enc_key_b64)

            self.encrypted_msg_text.delete("1.0", tk.END)
            self.encrypted_msg_text.insert(tk.END, enc_msg_b64)

            # Update output
            self.output_area.delete(1.0, tk.END)
            self.output_area.insert(tk.END, "✅ Message encoded & encrypted successfully.\n")
            self.output_area.insert(tk.END, "🔑 Encrypted AES key and message placed in respective fields.\n")

        except Exception as e:
            messagebox.showerror("Encryption Error", str(e))

    def decrypt_decode(self):
        enc_key_b64 = self.encrypted_key_text.get("1.0", tk.END).strip()
        enc_msg_b64 = self.encrypted_msg_text.get("1.0", tk.END).strip()

        if not enc_key_b64 or not enc_msg_b64:
            messagebox.showwarning("Missing Fields", "Please paste the encrypted key and message.")
            return

        try:
            decoded_encoded = self.encryptor.decrypt(enc_key_b64, enc_msg_b64)
            final_decoded = self.encoder.decode(decoded_encoded)

            self.output_area.insert(tk.END, f"\n\n🧩 Decrypted (Encoded Form):\n{decoded_encoded}\n")
            self.output_area.insert(tk.END, f"📩 Final Decoded Message:\n{final_decoded}\n")

        except Exception as e:
            messagebox.showerror("Decryption Error", str(e))


# ------------ Run App ------------
if __name__ == "__main__":
    root = tk.Tk()
    app = EncoderApp(root)
    root.mainloop()
